package com.example.demo.model;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="employees")
public class Employee {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)

private long id;
@Column(name="name")//if we want to add name 
private String name;
@Column(name="email")
private String email;
@Column(nullable = false)
@Temporal(TemporalType.TIMESTAMP)
private Date dob;
@Column
private int age;
@Column(nullable = false)
private double salary;

@Column(nullable = false)
private boolean status;
public Employee() {
	
}


public Employee(long id, String name, String email, Date dob, int age, double salary, boolean status) {
	super();
	this.id = id;
	this.name = name;
	this.email = email;
	this.dob = dob;
	this.age = age;
	this.salary = salary;
	this.status = status;
}


public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public boolean isStatus() {
	return status;
}
public void setStatus(boolean status) {
	this.status = status;
}

@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", email=" + email + ", dob=" + dob + ", age=" + age + ", salary="
			+ salary + ", status=" + status + ", getId()=" + getId() + ", getName()=" + getName() + ", getEmail()="
			+ getEmail() + ", getDob()=" + getDob() + ", getAge()=" + getAge() + ", getSalary()=" + getSalary()
			+ ", isStatus()=" + isStatus() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
			+ ", toString()=" + super.toString() + "]";
}
}


