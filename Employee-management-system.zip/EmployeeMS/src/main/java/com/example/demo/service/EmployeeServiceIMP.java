package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFound;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceIMP implements EmployeeService {

    private EmployeeRepository employeeRepo;

    @Autowired
    public EmployeeServiceIMP(EmployeeRepository employeeRepo) {
        this.employeeRepo = employeeRepo;
    }

    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeRepo.save(employee);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepo.findAll();
    }

    @Override
    public Employee getEmployeeById(long id) {
        return employeeRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFound("Employee", "Id", id));
    }

    @Override
    public Employee updateEmployee(Employee employee, long id) {
        // Check if the employee with the given id exists in the database
        Employee existingEmployee = employeeRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFound("Employee", "Id", id));

        // Update the existing employee's properties with the new values
        existingEmployee.setName(employee.getName());
        existingEmployee.setEmail(employee.getEmail());
        existingEmployee.setDob(employee.getDob()); 
        existingEmployee.setAge(employee.getAge());
        existingEmployee.setSalary(employee.getSalary());
        existingEmployee.setStatus(employee.isStatus());

        // Save the updated employee to the database
        return employeeRepo.save(existingEmployee);
    }

    @Override
    public void deleteEmployee(long id) {
        // Check if the employee with the given id exists in the database
        employeeRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFound("Employee", "Id", id));

        // Delete the employee from the database
        employeeRepo.deleteById(id);
    }
}
