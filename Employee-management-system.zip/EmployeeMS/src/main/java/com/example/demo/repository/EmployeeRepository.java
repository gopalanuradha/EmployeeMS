package com.example.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Employee;
public interface EmployeeRepository extends JpaRepository<Employee,Long> {
//JPA repository require 2 parameter 1. entity 2. type of parameter
}
